package com.sistema.trailers;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MiniSistemaTrailersApplicationTests {

	@Test
	void contextLoads() {
	}

}
